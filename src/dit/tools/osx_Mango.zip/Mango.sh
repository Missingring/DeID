#!/bin/bash

mydir=$(cd "$( dirname ${BASH_SOURCE[0]} )" && pwd )
if [ $# -eq 1 ]; then
	java -jar "$mydir"/Mango.jar $1
else
	java -jar "$mydir"/Mango.jar
fi