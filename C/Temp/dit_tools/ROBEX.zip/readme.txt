Robust Brain Extraction (ROBEX)  v1.1
Author: Juan Eugenio Iglesias
Email: iglesias@nmr.mgh.harvard.edu
www: http://www.jeiglesias.com
--------------------------------------


Citation:

Iglesias JE, Liu CY, Thompson P, Tu Z: "Robust Brain Extraction Across
Datasets and Comparison with Publicly Available Methods", IEEE Transactions
on Medical Imaging, 30(9), 2011, 1617-1634.



Usage:    

  runROBEX.bat inputFile strippedFile [outputMaskFile] [seed]


Important details:

- The input file is supposed to be oriented as the volume "atlas"
in the folder "ref_vols": x = left->right, y = posterior->anterior,
z=inferior->superior.  If you get a completely wrong segmentation
with the shape of a brain, try changing the orientation of the
input scan.

- The behavior of ROBEX is not deterministic. Therefore, you might
observe (very) slight differences between the outputs of different
runs on the same scan. If you need results that can be exactly
reproduced, you can provide ROBEX with a seed (which must be >=0).

- ROBEX has been tested with images in Analyze format (.hdr/.img), 
but any ITK-supported format should work.

- ROBEX is designed to be robust. If ROBEX doesn't produce decent 
results for a given volume, I'd very much appreciate it if you let
me know by email (iglesias@nmr.mgh.harvard.edu).

- Please read license.txt!


----------------
CHANGES WITH RESPECT TO VERSION 1.0
----------------- 

- ROBEX does not depend on the random forest library anymore, and therefore
it is now completely BSD.

- ROBEX is now called from a wrapper such that it is not required to run 
the software from the ROBEX directory anymore. In Linux, this wrapper also
ensures that the Elastix directory is in the library path.

- The wrapper also adds the Elastix directory to the library path.

- Added the option of specifying a seed in the command line so that the 
output of the algorithm is deterministic (and therefore reproducible).












